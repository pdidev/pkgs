#!/bin/echo 'please source this file, do not run it'

if [ -z "$PDI_DIR" ]; then

# this in in share/pdi/, go up two directories
export PDI_DIR="$(readlink -f "$(dirname "${BASH_SOURCE[0]}")/../../")"

if [ -n "$PATH" ]; then
	export PATH="${PDI_DIR}/bin/:$PATH"
else
	export PATH="${PDI_DIR}/bin/"
fi

if [ -n "$LD_LIBRARY_PATH" ]; then
	export LD_LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/:$LD_LIBRARY_PATH"
else
	export LD_LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/"
fi

if [ -n "$PYTHONPATH" ]; then
	export PYTHONPATH="${PDI_DIR}/lib/python3/dist-packages/:$PYTHONPATH"
else
	export PYTHONPATH="${PDI_DIR}/lib/python3/dist-packages/"
fi

if [ -n "$LIBRARY_PATH" ]; then
	export LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/:$LIBRARY_PATH"
else
	export LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/"
fi

if [ -n "$CPATH" ]; then
	export CPATH="${PDI_DIR}/include/:$CPATH"
else
	export CPATH="${PDI_DIR}/include/"
fi

if [ -n "$PATH" ]; then
	export PATH="${PDI_DIR}/bin/:$PATH"
else
	export PATH="${PDI_DIR}/bin/"
fi

echo "Environment loaded for PDI version 0.6.5"

fi # [ -z "$PDI_DIR" ]
