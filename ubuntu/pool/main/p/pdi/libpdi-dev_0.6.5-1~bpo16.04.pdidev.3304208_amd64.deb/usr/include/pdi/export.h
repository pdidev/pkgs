
#ifndef PDI_EXPORT_H
#define PDI_EXPORT_H

#ifdef PDI_STATIC_DEFINE
#  define PDI_EXPORT
#  define PDI_NO_EXPORT
#else
#  ifndef PDI_EXPORT
#    ifdef pdi_EXPORTS
        /* We are building this library */
#      define PDI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PDI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PDI_NO_EXPORT
#    define PDI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PDI_DEPRECATED
#  define PDI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PDI_DEPRECATED_EXPORT
#  define PDI_DEPRECATED_EXPORT PDI_EXPORT PDI_DEPRECATED
#endif

#ifndef PDI_DEPRECATED_NO_EXPORT
#  define PDI_DEPRECATED_NO_EXPORT PDI_NO_EXPORT PDI_DEPRECATED
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define PDI_NO_DEPRECATED
#endif

#endif
